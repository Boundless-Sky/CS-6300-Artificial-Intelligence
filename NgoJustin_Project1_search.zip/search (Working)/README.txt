search.py - Where all of your search algorithms will reside.

searchAgents.py - Where all your search-based agents will reside. 

pacman.py - the main file that runs pacman games. This file describes a pacman gamestate type, which you can use in this project. 

game.py - the logic behind how the pacman world works. this file describes several supporting typles like Agentstate, Agent, Direction, and Grid. 

util.py - Useful data structures for implemnting search algorithms. 

graphicsDisplay.py - Graphics for Pacman

graphicsUtils.py -Support for Pacman graphics

textDisplay.py - ASCII graphics for Pacman

ghostAgents.py - Agents to control ghosts

keboardAgents.py - Keyboard interfaces to control Pacman

layout.py - code for reading layout files and storing their contents

autograder.py - project autograder

testParser.py - Parses autograder test and solution files

testClasses.py - General autograding test classes

test_cases/ Dirrectory containin the test cases for each question

searchTestClasses.py - project 1 specific autograding test classes. 