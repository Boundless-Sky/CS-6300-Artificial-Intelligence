# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).
from util import Stack


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    """
    --------------------------------------Justin Ngo, Spring AI 2018------------------------------------
    
    *Notes*
    getStartState gives you tuple (unchangable list) of [(x,y),action, cost] ~ i.e. [(1,2),West,2]
    upcomingExploration[0] = state  ~  i.e (x,y)
    upcomingExploration[1] = action ~  i.e South
    upcomingExploration[2] = cost   ~  i.e 1
    ----------------------------------------------------------------------------------------------------
    """
    # create a list of searched nodes 
    chartedNodes = [] 
    
    # record action taken as in dictionaries (keys: content)
    chartedActions = {}
    chartedCost = {}
    chartedPlan = {}
    
    # pacman action plan
    PacmanGo = []
    
    # type of data structure to handle the frontier
    frontier = util.Stack()
    
    # push the root node onto the stack and start searching
    rootNode = problem.getStartState()
    # make the same tuple structure that successor outputs
    frontier.push([(rootNode, "starting_point", 0)])
    
    # iteratively check the successors and then find the ancestral line when the sucessor is the choosen one
    while not frontier.isEmpty():
        # start checking the fringes
        searchingNode = frontier.pop()
        
        # just want to save/check the location of the node. Don't care about the action nor the cost
        location = searchingNode[len(searchingNode)-1]
        location = location[0]
       
        # check if the goal is at the location being tested
        if problem.isGoalState(location):
            while location in chartedPlan:
                # add the action the pacman's action plan
                PacmanGo.append(chartedActions[location])
                # open the key that the next plan will be at 
                location = chartedPlan[location]
            # started at goal state so reverse do get path    
            PacmanGo.reverse()
            return PacmanGo
        
        # add location if it wasn't previously searched
        if location not in chartedNodes:    
            chartedNodes.append(location)
      
            # get the next state
            for upcomingExploration in problem.getSuccessors(location):
                # detemine whether our next expedition is already charted.
                if upcomingExploration[0] not in chartedNodes:
                    # add to the fringe to be searched
                    chartedRoute = searchingNode[:]
                    chartedRoute.append(upcomingExploration)
                    # write down what was the action/cost/plan to get where we were. 
                    chartedPlan[upcomingExploration[0]] = location
                    chartedActions[upcomingExploration[0]] = upcomingExploration[1] 
                    chartedCost[upcomingExploration[0]] = upcomingExploration[2]                   
                    frontier.push(chartedRoute)
    
    util.raiseNotDefined()

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    """
    --------------------------------------Justin Ngo, Spring AI 2018------------------------------------
    
    *Notes*
    getStartState gives you tuple (unchangable list) of [(x,y),action, cost] ~ i.e. [(1,2),West,2]
    upcomingExploration[0] = state  ~  i.e (x,y)
    upcomingExploration[1] = action ~  i.e South
    upcomingExploration[2] = cost   ~  i.e 1
    ----------------------------------------------------------------------------------------------------
    """
    # create a list of searched nodes 
    chartedNodes = [] 
    
    # record action taken as in dictionaries (keys: content)
    chartedActions = {}
    chartedCost = {}
    chartedPlan = {}
    
    # pacman action plan
    PacmanGo = []
    
    # type of data structure to handle the frontier
    frontier = util.Queue()
    
    # push the root node onto the stack and start searching
    rootNode = problem.getStartState()
    # make the same tuple structure that successor outputs
    frontier.push([(rootNode, "starting_point", 0)])
    
    # iteratively check the successors and then find the ancestral line when the sucessor is the choosen one
    while not frontier.isEmpty():
        # start checking the fringes
        searchingNode = frontier.pop()
        
        # just want to save/check the location of the node. Don't care about the action nor the cost
        location = searchingNode[len(searchingNode)-1]
        location = location[0]
       
        # check if the goal is at the location being tested
        if problem.isGoalState(location):
            for plan in searchingNode:
                PacmanGo.append(plan[1])
            return PacmanGo[1:]
#             while location in chartedPlan:
#                 # add the action the pacman's action plan
#                 PacmanGo.append(chartedActions[location])
#                 # open the key that the next plan will be at 
#                 location = chartedPlan[location]
#             # started at goal state so reverse do get path    
#             PacmanGo.reverse()
#             return PacmanGo
        
        
        # add location if it wasn't previously searched
        if location not in chartedNodes:    
            chartedNodes.append(location)
      
            # get the next state
            for upcomingExploration in problem.getSuccessors(location):
                # detemine whether our next expedition is already charted.
                if upcomingExploration[0] not in chartedNodes:
                    # add to the fringe to be searched
                    chartedRoute = searchingNode[:]
                    chartedRoute.append(upcomingExploration)
                    # write down what was the action/cost/plan to get where we were. 
                    chartedPlan[upcomingExploration[0]] = location
                    chartedActions[upcomingExploration[0]] = upcomingExploration[1] 
                    chartedCost[upcomingExploration[0]] = upcomingExploration[2]                   
                    frontier.push(chartedRoute)
    
                
    util.raiseNotDefined()

#===============================================================================
# def determineCost(): 
#     costList = []
#     for cost in costList:
#         problem.getCostOfActions(costList)
#     return cost
#===============================================================================


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    """
    --------------------------------------Justin Ngo, Spring AI 2018------------------------------------
    
    *Notes*
    getStartState gives you tuple (unchangable list) of [(x,y),action, cost] ~ i.e. [(1,2),West,2]
    upcomingExploration[0] = state  ~  i.e (x,y)
    upcomingExploration[1] = action ~  i.e South
    upcomingExploration[2] = cost   ~  i.e 1
    ----------------------------------------------------------------------------------------------------
    """
    # create a list of searched nodes 
    chartedNodes = [] 
    
    # record action taken as in dictionaries (keys: content)
    chartedActions = {}
    chartedCost = {}
    chartedPlan = {}
    
    # pacman action plan
    PacmanGo = []
    
    # type of data structure to handle the frontier
    frontier = util.PriorityQueue()
    
    # push the root node onto the stack and start searching
    rootNode = problem.getStartState()
    # make the same tuple structure that successor outputs
    # need to have Stop because game.py needs it can't put random junk
    startPriority = 0
    priority = 0
    frontier.push([(rootNode, "Stop", 0)],startPriority)
   
    # iteratively check the successors and then find the ancestral line when the sucessor is the choosen one
    while not frontier.isEmpty():
        # start checking the fringes
       
        priority, searchingNode = frontier.pop()
        
        # just want to save/check the location of the node. Don't care about the action nor the cost
        location = searchingNode[len(searchingNode)-1]
        location = location[0]
        
       
        # check if the goal is at the location being tested
        if problem.isGoalState(location):
            for plan in searchingNode:
                PacmanGo.append(plan[1])
            return PacmanGo[1:]
        
        # add location if it wasn't previously searched
        if location not in chartedNodes:    
            chartedNodes.append(location)
      
            # get the next state
            for upcomingExploration in problem.getSuccessors(location):
                # detemine whether our next expedition is already charted.
                if upcomingExploration[2] not in chartedCost or (priority + upcomingExploration[2] < chartedCost[upcomingExploration[0]]) : 
                    # add to the fringe to be searched
                    chartedRoute = searchingNode[:]
                    chartedRoute.append(upcomingExploration)
                    # write down what was the action/cost/plan to get where we were. 
                    chartedPlan[upcomingExploration[0]] = location
                    chartedActions[upcomingExploration[0]] = upcomingExploration[1] 
                    chartedCost[upcomingExploration[0]] = upcomingExploration[2] + priority           
                    frontier.update(chartedRoute,chartedCost[upcomingExploration[0]])
                    
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    """
    --------------------------------------Justin Ngo, Spring AI 2018------------------------------------
    
    *Notes*
    getStartState gives you tuple (unchangable list) of [(x,y),action, cost] ~ i.e. [(1,2),West,2]
    upcomingExploration[0] = state  ~  i.e (x,y)
    upcomingExploration[1] = action ~  i.e South
    upcomingExploration[2] = cost   ~  i.e 1
    ----------------------------------------------------------------------------------------------------
    """
    # create a list of searched nodes 
    chartedNodes = [] 
    
    # record action taken as in dictionaries (keys: content)
    chartedActions = {}
    chartedCost = {}
    chartedPlan = {}

    # pacman action plan
    PacmanGo = []
    
    # type of data structure to handle the frontier
    frontier = util.PriorityQueue()
    
    # push the root node onto the stack and start searching
    rootNode = problem.getStartState()
    # make the same tuple structure that successor outputs
    # need to have Stop because game.py needs it can't put random junk
    startPriority = 0
    frontier.push([(rootNode, "Stop", 0)],startPriority)
    
    # iteratively check the successors and then find the ancestral line when the sucessor is the choosen one
    while not frontier.isEmpty():
        # start checking the fringes
        priority, searchingNode = frontier.pop()
        
        # just want to save/check the location of the node. Don't care about the action nor the cost
        location = searchingNode[len(searchingNode)-1]
        location = location[0]
       
        # check if the goal is at the location being tested
        if problem.isGoalState(location):
            for plan in searchingNode:
                PacmanGo.append(plan[1])
            return PacmanGo[1:]
        
        # add location if it wasn't previously searched
        if location not in chartedNodes:    
            chartedNodes.append(location)
            
            # get the next state
            for upcomingExploration in problem.getSuccessors(location):
                h = heuristic(upcomingExploration[0], problem)
                chartedRoute = searchingNode[:]
                chartedRoute.append(upcomingExploration)
                g = 0
                for plancost in chartedRoute:
                    g += plancost[2]
                gh = g + h
                # detemine whether our next expedition is already charted.
                if gh not in chartedCost or gh < chartedCost[upcomingExploration[0]]: 
                    # add to the fringe to be searched
                    # write down what was the action/cost/plan to get where we were. 
                    chartedPlan[upcomingExploration[0]] = location
                    chartedActions[upcomingExploration[0]] = upcomingExploration[1] 
                    chartedCost[upcomingExploration[0]] = gh
                    frontier.update(chartedRoute, chartedCost[upcomingExploration[0]])
                    
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
